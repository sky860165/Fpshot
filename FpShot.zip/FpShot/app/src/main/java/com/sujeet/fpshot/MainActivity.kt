package com.sujeet.fpshot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "1. Accessibility Settings kholo, 'FP Screenshot' ON karo -> screen pe chhota ☰ icon aa jayega\n" +
                "2. Icon touch karo: 🔊 volume up, 🔉 volume down, 📸 screenshot, 🔔 ring/vibrate/silent\n" +
                "3. Icon ko drag karke kahin bhi rakh sakte ho\n" +
                "4. Silent mode ke liye neeche wala button dabake Do Not Disturb access do"
        })
        root.addView(Button(this).apply {
            text = "Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Do Not Disturb access (silent ke liye)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        })
        setContentView(root)
    }
}
