package com.sujeet.fpshot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.FingerprintGestureController
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class FpService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var am: AudioManager
    private lateinit var root: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private val h = Handler(Looper.getMainLooper())
    private val collapse = Runnable { if (::panel.isInitialized) panel.visibility = View.GONE }
    private var fpCb: FingerprintGestureController.FingerprintGestureCallback? = null

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (!::root.isInitialized) buildOverlay()
        setupFingerprint()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun circle(c: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(c)
    }

    private fun touched() {
        h.removeCallbacks(collapse)
        h.postDelayed(collapse, 4000)
    }

    private fun btn(label: String, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 20f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = circle(0xCC222222.toInt())
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { topMargin = dp(6) }
        setOnClickListener { action(); touched() }
    }

    private fun buildOverlay() {
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(200)
        }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val bubble = TextView(this).apply {
            text = "☰"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = circle(0xCC000000.toInt())
            alpha = 0.8f
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(btn("🔊") { volume(AudioManager.ADJUST_RAISE) })
            addView(btn("🔉") { volume(AudioManager.ADJUST_LOWER) })
            addView(btn("📸") { screenshot() })
            addView(btn("🔔") { cycleRinger() })
        }

        root.addView(bubble)
        root.addView(panel)

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + dx.toInt()
                        lp.y = sy + dy.toInt()
                        wm.updateViewLayout(root, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (panel.visibility == View.VISIBLE) {
                        panel.visibility = View.GONE
                    } else {
                        panel.visibility = View.VISIBLE
                        touched()
                    }
                }
            }
            true
        }

        wm.addView(root, lp)
    }

    private fun volume(dir: Int) {
        am.adjustSuggestedStreamVolume(dir, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI)
    }

    private fun screenshot() {
        panel.visibility = View.GONE
        root.visibility = View.INVISIBLE // icon screenshot me na aaye
        h.postDelayed({
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            h.postDelayed({ root.visibility = View.VISIBLE }, 1200)
        }, 350)
    }

    private fun cycleRinger() {
        try {
            val (next, name) = when (am.ringerMode) {
                AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE to "Vibrate 📳"
                AudioManager.RINGER_MODE_VIBRATE -> AudioManager.RINGER_MODE_SILENT to "Silent 🔇"
                else -> AudioManager.RINGER_MODE_NORMAL to "Ring 🔔"
            }
            am.ringerMode = next
            Toast.makeText(this, name, Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Silent ke liye Do Not Disturb access ON karo", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun setupFingerprint() {
        val c = fingerprintGestureController
        if (!c.isGestureDetectionAvailable) return
        fpCb = object : FingerprintGestureController.FingerprintGestureCallback() {
            override fun onGestureDetected(gesture: Int) { screenshot() }
        }
        c.registerFingerprintGestureCallback(fpCb!!, Handler(Looper.getMainLooper()))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        fpCb?.let { fingerprintGestureController.unregisterFingerprintGestureCallback(it) }
        if (::root.isInitialized) try { wm.removeView(root) } catch (_: Exception) {}
        super.onDestroy()
    }
}
